package airflow_controller_system;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AirflowControllerApplicationTests {

	@Test
	void contextLoads() {
	}

}
